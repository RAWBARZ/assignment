import { useParams } from "react-router-dom";

const Home = ({ name, age, address, email }) => {
  return (
    <div>
      <h1>Welcome, {name}!</h1>
      <p>Age: {age}</p>
      <p>Address: {address}</p>
      <p>Email: {email}</p>
    </div>
  );
};

export default Home;
