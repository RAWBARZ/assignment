import React, { useState, useNavigate, } from "react-router-dom";

const FormAction = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [address, setAddress] = useState("");
  const [email, setEmail] = useState("");

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    navigate("/?name=${name}&age=${age}&address=${address}&email=${email}"); // Collect form data and pass it to Home component
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        age:
        <input
          type="text"
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />
        address:
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
        email:
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  );
};

export default FormAction;
